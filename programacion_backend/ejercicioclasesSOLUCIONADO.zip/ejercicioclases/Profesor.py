class profesor:
    rut=""
    nombre=""
    profesion=""
    lista_asignaturas=[]

    def __init__(self,rut,nombre,profesion,lista_asignaturas):
        pass